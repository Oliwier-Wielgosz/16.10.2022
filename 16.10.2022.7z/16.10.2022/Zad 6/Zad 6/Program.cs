﻿using System;

namespace Zad_6
{
    internal class Program
    {
        public static int pot(int a = 1)
        {
            Console.WriteLine("Jaką liczbe chcesz potęgować:");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Do jakiej potęgi:");
            int x = int.Parse(Console.ReadLine());
            while (x > 0)
            {
                a *= n;
                x--;
            }
            return a;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(pot()); 
        }
    }
}
