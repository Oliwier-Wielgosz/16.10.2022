﻿using System;

namespace Zad_7
{
    internal class Program
    {
        public static string bin(string b = "")
        {
            int a = int.Parse(Console.ReadLine());
            while (a != 0)
            {
                if (a % 2 == 0) b = "0" + b;
                else b = "1" + b;
                a = a / 2;
            }
            return b;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(bin());
        }
    }
}
