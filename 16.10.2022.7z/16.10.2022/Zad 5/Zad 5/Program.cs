﻿using System;

namespace Zad_5
{
    internal class Program
    {
        public static int fib(int suma = 0)
        {
            int a = int.Parse(Console.ReadLine());
            int b = -1;
            int c = 1;
            for (int i = 0; i < a; i++)
            {
                suma = b + c;
                b = c;
                c = suma;
                Console.WriteLine(c);
            }
            return c;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(fib());
        }
    }
}
